import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Door } from "@/components/site/door";
import { Shell } from "@/components/site/shell";
import { useSite } from "@/lib/store";

export const Route = createFileRoute("/")({ component: HomeRoute });

function HomeRoute() {
  const hydrated = useSite((s) => s.hydrated);
  const unlocked = useSite((s) => s.unlocked);
  const hydrate = useSite((s) => s.hydrate);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  if (hydrated && unlocked) {
    return <Shell />;
  }

  return <Door />;
}
