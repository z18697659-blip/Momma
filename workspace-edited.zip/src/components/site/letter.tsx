import { LETTER } from "@/lib/content";

export function Letter() {
  return (
    <div className="mx-auto max-w-lg px-4 pb-8 pt-8">
      <p className="enter px-2 text-xs tracking-[0.28em] text-clay uppercase">A letter for you</p>
      <article className="enter enter-d1 glass mt-5 rounded-[2rem] px-7 py-10">
        <h1 className="text-gradient font-display text-6xl font-medium italic leading-none">{LETTER.greeting}</h1>
        <div className="mt-8 space-y-5">
          {LETTER.paragraphs.map((p) => (
            <p key={p.slice(0, 24)} className="font-display text-2xl font-normal leading-snug text-fg/95">
              {p}
            </p>
          ))}
        </div>
        <p className="mt-10 font-display text-3xl italic text-clay">{LETTER.signoff}</p>
      </article>
    </div>
  );
}
