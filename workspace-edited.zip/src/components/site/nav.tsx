import { BookOpen, Flame, House, Images } from "lucide-react";
import { cn } from "@/lib/utils";
import { useSite, type View } from "@/lib/store";

const ITEMS: { id: View; label: string; icon: typeof House }[] = [
  { id: "home", label: "Home", icon: House },
  { id: "us", label: "Photos", icon: Images },
  { id: "letter", label: "Letter", icon: BookOpen },
  { id: "nasty", label: "Nasty", icon: Flame },
];

export function BottomNav() {
  const view = useSite((s) => s.view);
  const setView = useSite((s) => s.setView);

  return (
    <nav
      className="fixed inset-x-4 bottom-[max(1rem,env(safe-area-inset-bottom))] z-40 mx-auto max-w-md"
      aria-label="Pages"
    >
      <ul className="glass grid grid-cols-4 gap-1 rounded-full p-1.5">
        {ITEMS.map((item) => {
          const active = view === item.id;
          const Icon = item.icon;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => setView(item.id)}
                className={cn(
                  "flex h-14 w-full flex-col items-center justify-center gap-0.5 rounded-full text-[11px] tracking-wide transition-[background-color,color] duration-200",
                  active ? "bg-accent text-accent-fg" : "text-subtle hover:text-muted",
                )}
              >
                <Icon className="size-[18px]" strokeWidth={active ? 2.2 : 1.7} />
                {item.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
