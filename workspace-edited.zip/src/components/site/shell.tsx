import { useSite } from "@/lib/store";
import { BottomNav } from "@/components/site/nav";
import { Home } from "@/components/site/home";
import { Photos } from "@/components/site/photos";
import { Letter } from "@/components/site/letter";
import { Nasty } from "@/components/site/nasty";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Shell() {
  const view = useSite((s) => s.view);
  const lock = useSite((s) => s.lock);

  return (
    <div className="relative min-h-dvh bg-bg text-fg">
      <div className="aurora" aria-hidden="true" />
      {view === "home" ? (
        <div className="fixed right-3 top-[max(0.75rem,env(safe-area-inset-top))] z-30">
          <Button
            variant="ghost"
            className="glass h-11 gap-2 rounded-full px-4 text-xs tracking-[0.18em] text-fg uppercase hover:bg-accent/20"
            onClick={lock}
          >
            <Lock className="size-4 text-accent" strokeWidth={2} />
            Lock
          </Button>
        </div>
      ) : null}

      <main className="relative z-10 pb-28">
        {view === "home" ? <Home /> : null}
        {view === "us" ? <Photos /> : null}
        {view === "letter" ? <Letter /> : null}
        {view === "nasty" ? <Nasty /> : null}
      </main>
      <BottomNav />
    </div>
  );
}
