import { FormEvent, useState } from "react";
import { SITE, isDoorPhrase } from "@/lib/content";
import { useSite } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { HeartMark } from "@/components/site/heart";

export function Door() {
  const unlock = useSite((s) => s.unlock);
  const [value, setValue] = useState("");
  const [tries, setTries] = useState(0);
  const [shake, setShake] = useState(false);
  const [wrong, setWrong] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (isDoorPhrase(value)) {
      unlock();
      return;
    }
    setTries((n) => n + 1);
    setWrong(true);
    setShake(true);
    window.setTimeout(() => setShake(false), 420);
  }

  return (
    <main className="grain relative min-h-dvh overflow-hidden bg-bg text-fg">
      <div className="aurora" aria-hidden="true" />
      <img
        src="/photos/us-heart.jpg"
        alt=""
        className="absolute inset-0 size-full scale-110 object-cover object-[center_32%] opacity-40 blur-sm"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-bg/30 via-bg/50 to-bg" />

      <div className="relative z-10 mx-auto flex min-h-dvh max-w-md items-end justify-center px-4 pb-8 sm:items-center">
        <div className="glass enter w-full rounded-[2rem] p-7">
          <h1 className="text-gradient font-display text-5xl font-medium leading-none italic sm:text-6xl">
            {SITE.passwordPrompt}.
          </h1>

          <form onSubmit={onSubmit} className="mt-8 space-y-4">
            <label className="block">
              <span className="sr-only">Your answer</span>
              <input
                suppressHydrationWarning
                autoComplete="off"
                autoCapitalize="off"
                spellCheck={false}
                value={value}
                onChange={(e) => {
                  setValue(e.target.value);
                  setWrong(false);
                }}
                placeholder="Type it here"
                className={`h-13 w-full rounded-full bg-black/30 px-5 text-base text-fg shadow-[var(--shadow-border)] outline-none placeholder:text-subtle focus:shadow-[var(--shadow-border-hover)] ${
                  shake ? "animate-pulse" : ""
                }`}
              />
            </label>
            <Button type="submit" variant="accent" className="w-full" size="lg">
              Open the door
            </Button>
            {wrong ? (
              <p className="flex items-center gap-2 text-sm text-clay">
                <HeartMark className="size-3.5 text-accent" />
                {tries >= 2 ? SITE.passwordHint : "Not that one. Try again."}
              </p>
            ) : null}
          </form>
        </div>
      </div>
    </main>
  );
}
