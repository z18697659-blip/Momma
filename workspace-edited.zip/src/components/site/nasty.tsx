import { NASTY } from "@/lib/content";

export function Nasty() {
  return (
    <div className="mx-auto max-w-lg px-4 pb-8 pt-8">
      <p className="enter px-2 text-xs tracking-[0.28em] text-clay uppercase">Just us</p>
      <h1 className="enter text-gradient mt-2 px-2 font-display text-6xl font-medium italic leading-tight">Nasty.</h1>

      <article className="enter enter-d1 glass mt-6 rounded-[2rem] px-7 py-10">
        <div className="space-y-5">
          {NASTY.paragraphs.map((p) => (
            <p key={p.slice(0, 24)} className="font-display text-2xl font-normal leading-snug text-fg/95">
              {p}
            </p>
          ))}
          <p className="pt-4 font-display text-3xl italic text-clay">{NASTY.signoff}</p>
        </div>
      </article>
    </div>
  );
}
