import { useSite } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { HeartMark } from "@/components/site/heart";

export function Home() {
  const setView = useSite((s) => s.setView);

  return (
    <div className="p-3 pb-0">
      <div className="grain relative h-[calc(100dvh-7.5rem)] min-h-[32rem] overflow-hidden rounded-[2rem] shadow-[0_30px_80px_-30px_rgb(0_0_0/0.9)]">
        <img
          src="/photos/sun.jpg"
          alt="A smiling woman by the water"
          className="absolute inset-0 size-full object-cover object-[center_18%]"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-bg/10 to-bg/80" />

        <div className="relative z-10 flex h-full flex-col justify-end p-3">
          <div className="glass rounded-[1.6rem] p-6">
            <h1 className="enter text-gradient font-display text-6xl font-medium leading-[0.95] italic sm:text-7xl">
              For you.
            </h1>
            <p className="enter enter-d1 mt-3 text-base leading-relaxed text-fg/90">
              A little place I made for you.
            </p>
            <div className="enter enter-d2 mt-6 flex flex-wrap gap-3">
              <Button variant="accent" onClick={() => setView("letter")}>
                Read the letter
              </Button>
              <Button variant="outline" onClick={() => setView("us")}>
                See our photos
              </Button>
            </div>
            <p className="enter enter-d3 mt-6 flex items-center gap-2 text-sm text-muted">
              <HeartMark className="size-3.5 text-accent" filled />
              I love you.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
