import { cn } from "@/lib/utils";

export function HeartMark({ className, filled = false }: { className?: string; filled?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className={cn("size-4", className)}
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinejoin="round"
    >
      <path d="M12 20s-7-4.4-7-10.2C5 6.7 6.8 5 9 5c1.3 0 2.4.6 3 1.6C12.6 5.6 13.7 5 15 5c2.2 0 4 1.7 4 4.8C19 15.6 12 20 12 20z" />
    </svg>
  );
}
