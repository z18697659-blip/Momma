import { PHOTOS } from "@/lib/content";

export function Photos() {
  return (
    <div className="mx-auto max-w-lg px-4 pb-8 pt-8">
      <header className="enter mb-8 px-2">
        <p className="text-xs tracking-[0.28em] text-clay uppercase">Our photos</p>
        <h1 className="text-gradient mt-2 font-display text-6xl font-medium italic leading-tight">Us.</h1>
      </header>

      <div className="space-y-6">
        {PHOTOS.map((photo, i) => (
          <figure
            key={photo.src}
            className={`enter relative overflow-hidden rounded-[2rem] shadow-[0_30px_70px_-30px_rgb(0_0_0/0.9)] ${i % 2 === 1 ? "enter-d2" : "enter-d1"}`}
          >
            <img src={photo.src} alt={photo.alt} className={`aspect-[3/4] w-full object-cover ${photo.src.includes("selfie") ? "object-[center_60%]" : ""}`}
            />
            <figcaption className="absolute inset-x-0 bottom-0 space-y-1.5 bg-gradient-to-t from-black/85 via-black/45 to-transparent px-6 pb-6 pt-28">
              <h2 className="text-gradient font-display text-3xl italic leading-none">{photo.title}</h2>
              <p className="text-sm leading-relaxed text-fg/85">{photo.caption}</p>
            </figcaption>
          </figure>
        ))}
      </div>
    </div>
  );
}
