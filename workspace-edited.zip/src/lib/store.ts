import { create } from "zustand";

export type View = "home" | "us" | "letter" | "nasty";

const UNLOCK_KEY = "for-you.unlocked";

type SiteState = {
  hydrated: boolean;
  unlocked: boolean;
  view: View;
  hydrate: () => void;
  unlock: () => void;
  lock: () => void;
  setView: (view: View) => void;
};

export const useSite = create<SiteState>((set) => ({
  hydrated: false,
  unlocked: false,
  view: "home",
  hydrate: () => {
    const unlocked = localStorage.getItem(UNLOCK_KEY) === "1";
    set({ hydrated: true, unlocked });
  },
  unlock: () => {
    localStorage.setItem(UNLOCK_KEY, "1");
    set({ unlocked: true, view: "home" });
  },
  lock: () => {
    localStorage.removeItem(UNLOCK_KEY);
    set({ unlocked: false, view: "home" });
  },
  setView: (view) => {
    const change = () => set({ view });
    if (typeof document !== "undefined" && "startViewTransition" in document) {
      (document as Document & { startViewTransition: (cb: () => void) => unknown }).startViewTransition(change);
    } else {
      change();
    }
  },
}));
