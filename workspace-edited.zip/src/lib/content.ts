export const SITE = {
  passwordPrompt: "Say my name beiby",
  passwordHint: "Hint: three words. You say them to me all the time.",
} as const;

export function isDoorPhrase(value: string) {
  const n = value
    .toLowerCase()
    .replace(/['’]/g, "")
    .replace(/[^a-z\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return n.includes("i love you") || n === "love you";
}

export const PHOTOS = [
  {
    src: "/photos/us-heart.jpg",
    alt: "Two people making a heart with their hands",
    title: "Happiness",
    caption: "Our hands made a heart. This is my favorite photo.",
  },
  {
    src: "/photos/us-smile.jpg",
    alt: "Two people smiling together",
    title: "That smile",
    caption: "I was not hiding anything. I was just happy you were there.",
  },
  {
    src: "/photos/sun.jpg",
    alt: "A smiling woman by the water with her hands on her cheeks",
    title: "In the sun",
    caption: "By the water, smiling. You made the whole day better.",
  },
  {
    src: "/photos/duck-face.jpg",
    alt: "A woman making a playful duck face",
    title: "Silly you",
    caption: "Your funny face always makes me smile.",
  },
  {
    src: "/photos/selfie.jpg",
    alt: "A man taking a selfie in an empty classroom, making a peace sign",
    title: "Thinking of you",
    caption: "Empty room, full heart. You are on my mind.",
  },
  {
    src: "/photos/wink.jpg",
    alt: "A woman winking and smiling",
    title: "This one",
    caption: "This wink gets me every time.",
  },
] as const;

export const LETTER = {
  greeting: "Beiby,",
  paragraphs: [
    "I wanted you to know that you make my days better. Your smile, your laugh, and even your attitudes😌😂.",
    "I hope we spend the rest of our lives together, with more and more time together.",
    "Thank you for being mine. I am so happy with you.",
  ],
  signoff: "Have a good day beiby❤️",
};

export const NASTY = {
  paragraphs: [
    "Beiby, I really enjoy the time we spend together, that alone means alot to me. I love every nasty thing we do together, kissing, hugging, mechi 😊, kila kitu.",
    "I want more of that, I really miss you like everytime, you have become my favourite, trust me am yours.",
    "Babe, I will always choose you💕.",
  ],
  signoff: "Nakupenda sana MAMA😘💕",
};
